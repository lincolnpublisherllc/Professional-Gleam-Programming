erl -s observer
