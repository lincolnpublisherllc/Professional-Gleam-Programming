curl -sSL https://dl.gleam.run | sh
