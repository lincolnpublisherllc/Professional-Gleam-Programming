brew install gleam-lang/tap/gleam
For Linux (Ubuntu/Debian):
