gleam build
